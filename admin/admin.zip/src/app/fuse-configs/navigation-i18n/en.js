const locale = {
	APPLICATIONS: 'Applications',
	EXAMPLE: 'Example'
};

export default locale;
