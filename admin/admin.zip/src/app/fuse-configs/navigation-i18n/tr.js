const locale = {
	APPLICATIONS: 'Programlar',
	EXAMPLE: 'Örnek Sayfa'
};

export default locale;
