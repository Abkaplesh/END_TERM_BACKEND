import layout1 from './layout1/Layout1Config';

const FuseLayoutConfigs = {
	layout1
};

export default FuseLayoutConfigs;
