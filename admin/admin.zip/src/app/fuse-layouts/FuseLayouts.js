import layout1 from 'app/fuse-layouts/layout1/Layout1';

const FuseLayouts = {
	layout1
};

export default FuseLayouts;
