import React from 'react'

export const Shippingpolicy = () => {
    return (
        <div>
            
        </div>
    )
}
